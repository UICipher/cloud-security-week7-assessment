# LinkedIn Post Draft

I am pleased to share my Week 7 Cloud Security practical work completed during the **Summer of Cybersecurity 2026** program at **AstraQuantum Tech**, under the guidance of **Instructor Hazrat Umer**.

During this week, I worked through controlled cloud-security exercises focused on **AWS IAM enumeration**, **Amazon S3 enumeration**, and storage-exposure risks. The practical work helped me understand how excessive permissions, public storage access, and weak access controls can increase the impact of a compromised identity or exposed resource.

Key learning areas included:

- Reviewing IAM identities and effective permissions.
- Applying the principle of least privilege.
- Investigating S3 buckets and objects in an authorized lab environment.
- Understanding how public or overly broad storage access can lead to information disclosure.
- Mapping observations to practical defensive controls such as Block Public Access, restrictive resource policies, logging, and continuous monitoring.

This experience strengthened my ability to document cloud-security findings in a structured and responsible way. I am continuing to build my skills in cloud security, identity management, and security assessment.

**Program:** Summer of Cybersecurity 2026  
**Company:** AstraQuantum Tech  
**Instructor:** Hazrat Umer  

#CloudSecurity #AWS #IAM #AmazonS3 #CyberSecurity #InformationSecurity #CloudSecurity #LearningJourney

---

## Optional Short Bio

Cloud-security learner and cybersecurity intern focused on AWS IAM, Amazon S3 security, identity management, least privilege, and practical security assessment. Currently building hands-on experience through the **Summer of Cybersecurity 2026** at **AstraQuantum Tech** under the guidance of **Instructor Hazrat Umer**.
