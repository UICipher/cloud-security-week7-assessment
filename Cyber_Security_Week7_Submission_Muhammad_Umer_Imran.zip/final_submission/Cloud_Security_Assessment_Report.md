# ASTRAQUANTUM TECH
## Summer of Cybersecurity 2026 — Week 7

# Cloud Security Assessment Report

**Student Name:** Muhammad Umer Imran  
**Student ID:** AQT-1170  
**Instructor:** Hazrat Umer  
**Submission Date:** 18 September 2026  

---

## Submission Links

**LinkedIn Post URL:** ________________________________________________  

**GitHub Repository URL:** ____________________________________________  

> **Confidentiality note:** This report documents activity performed in authorized learning environments. No passwords, tokens, private keys, or sensitive account values are reproduced.

---

## Executive Summary

This report presents a practical review of cloud-security exercises completed in controlled training environments. The evidence set covers AWS Identity and Access Management (IAM) enumeration, AWS S3 storage enumeration, and a supplementary FlAWS storage-security exercise. The work focused on understanding how identity permissions and storage exposure can create security risk, rather than treating the exercises as simple flag-collection tasks.

The most important lessons were that cloud access should be granted according to least privilege, and storage resources should be treated as private by default. Excessive IAM permissions can expand the actions available to an unauthorized principal. Publicly reachable or weakly protected storage can expose files and configuration data. Both risks are reduced by careful policy review, restrictive resource settings, continuous monitoring, and regular access validation.

The evidence includes AWS Console views, completed Pwned Labs screens, and FlAWS challenge results. The screenshots support the lab observations, while the analysis distinguishes between a training finding and the impact that the same weakness could have in a real environment.

---

## 1. Scope

The assessment was limited to the following authorized learning resources and the supplied evidence:

1. **Intro to AWS IAM Enumeration** — Pwned Labs  
   URL: <https://app.pwnedlabs.io/labs/intro-to-aws-iam-enumeration>

2. **AWS S3 Enumeration Basics** — Pwned Labs  
   URL: <https://app.pwnedlabs.io/labs/aws-s3-enumeration-basics>

3. **FlAWS Challenge, Levels 1–2** — supplementary AWS S3 security exercise  
   URL: <http://flaws.cloud/>

The FlAWS exercise is included as supplementary evidence because the screenshots clearly show the FlAWS Level 1 and Level 2 challenge flow. It is not presented as one of the two Pwned Labs activities.

---

## 2. Methodology

The work followed a controlled, evidence-first approach. First, the lab context and target service were identified. Next, the relevant IAM, S3, or challenge interface was reviewed within the authorized training environment. The observed permission or exposure condition was then recorded in plain language. Finally, the likely impact and an appropriate defensive control were mapped to the observation.

The screenshots were reviewed as a set rather than in isolation. AWS Console screenshots 1a–1g show the IAM and S3 investigation path. Screenshot 1h shows the Pwned Labs IAM activity. Screenshot 2a shows the Pwned Labs S3 activity. Screenshots 2b–2i show the FlAWS challenge and its progression to the Level 2 result.

This report does not claim access to any production system. It also does not reproduce secrets or challenge values that would unnecessarily disclose sensitive information.

---

## 3. Lab Summaries

### 3.1 Intro to AWS IAM Enumeration

**Objective.** The exercise focused on identifying IAM identities and understanding the permissions attached to a user or role. The practical lesson was that an analyst should inspect identity context and policy scope before deciding whether an account has more access than required.

**Cloud service:** AWS IAM  
**Evidence:** AWS Console screenshots 1a–1d and Pwned Labs completion screen 1h.

**Security observation.** The evidence shows an IAM investigation that reaches a permissions boundary/policy view. This is the relevant control plane for determining whether a principal can perform actions beyond its intended role. The assessment treats the issue as **potential excessive or overly broad permission scope**, subject to confirmation against the complete policy document.

**Likely cause.** Broad managed policies, permissive inline statements, weak separation between administrative and operational roles, or an incorrectly configured permissions boundary can all create this condition.

**Potential impact.** If an unauthorized principal obtained the credentials of an over-permissioned identity, it might enumerate additional resources, access data, modify configurations, or escalate privileges depending on the allowed actions.

**Recommended control.** Apply least privilege. Replace broad permissions with narrowly scoped actions and resources, separate duties between roles, review permissions boundaries, enable CloudTrail visibility, and periodically remove unused permissions.

**Evidence caption.** The IAM evidence sheet combines the AWS Console context, identity and permissions review, and the related Pwned Labs activity completion state.

![IAM evidence sheet](report_assets/iam_evidence.png)

---

### 3.2 AWS S3 Enumeration Basics

**Objective.** The exercise focused on identifying an S3 bucket and examining the objects and access context visible in the authorized lab environment. The key lesson was that bucket-level and object-level settings must be reviewed together.

**Cloud service:** Amazon S3  
**Evidence:** AWS Console screenshots 1e–1g and Pwned Labs completion screen 2a.

**Security observation.** The evidence shows an S3 bucket and object path being inspected, including a directly viewed object/result. This demonstrates why storage exposure must be checked at both the bucket and object layers. A resource that is reachable more broadly than intended may allow unauthorized discovery or retrieval of files.

**Likely cause.** Common causes include public access settings, an over-broad bucket policy, an object ACL that does not match the intended access model, or failure to enable account-level S3 Block Public Access controls.

**Potential impact.** A real-world exposure could disclose documents, backups, logs, configuration files, or other data. Even a small non-secret file can reveal naming conventions, internal identifiers, or paths that help an attacker continue reconnaissance.

**Recommended control.** Keep S3 resources private by default. Enable Block Public Access at the account and bucket levels, use least-privilege bucket policies, disable legacy ACL use where possible, encrypt data, enable logging, and continuously scan for unintended public access.

**Evidence caption.** The S3 evidence sheet combines the bucket view, object listing, object/result inspection, and the related Pwned Labs activity completion state.

![S3 evidence sheet](report_assets/s3_evidence.png)

---

### 3.3 FlAWS Challenge — Levels 1–2 (Supplementary Practice)

**Objective.** The FlAWS exercise demonstrated how weakly protected S3 content can be discovered through predictable exposure and how a challenge participant can progress from an initial public page to a second-level result. The exercise reinforced the importance of preventing public access and avoiding sensitive information in publicly retrievable files.

**Cloud service:** Amazon S3  
**Evidence:** Screenshots 2b–2i.

**Security observation.** The screenshots show the FlAWS challenge page, source/content inspection, a Level 1 result, and the Level 2 completion message. This is a controlled demonstration of information disclosure through cloud storage exposure.

**Likely cause.** The training scenario intentionally places information in a location that can be reached or inferred through the exposed web content. In a real environment, similar exposure can result from public bucket policies, incorrect object permissions, predictable naming, or deployment artifacts being uploaded without review.

**Potential impact.** An attacker could retrieve exposed content, identify additional paths or resources, and use the information to improve reconnaissance. The impact becomes high when exposed content contains credentials, personal data, source code, backups, or internal configuration.

**Recommended control.** Enforce private-by-default storage, block public access, review object ownership and policies, remove sensitive data from public artifacts, use automated exposure detection, and include cloud-storage checks in deployment pipelines.

**Evidence caption.** The FlAWS evidence sheet shows the controlled challenge context, content inspection, Level 1 progression, Level 2 guidance, and visible completion result.

![FlAWS evidence sheet](report_assets/flaws_evidence.png)

---

## 4. Findings and Risk Assessment

### CLOUD-01 — Potentially excessive IAM permissions

**Cloud service:** AWS IAM  
**Severity:** Medium  

**Description.** The IAM evidence shows identity and policy review in the AWS Console. The relevant security concern is whether the effective permissions are broader than the principal's operational requirement.

**Evidence.** Screenshots 1b–1d show the IAM dashboard, identity context, and permissions/policy review. Screenshot 1h shows the related Pwned Labs IAM activity.

**Why is this risky?** An identity with unnecessary permissions increases the blast radius of a stolen credential, compromised session, or insider mistake. The final severity depends on the exact actions and resources allowed by the complete effective policy.

**Potential impact.** An attacker could enumerate resources, access data, change security settings, or attempt privilege escalation if the policy permits those actions.

**Recommendation.** Apply least privilege and separation of duties. Replace wildcard actions and resources with specific statements, review permissions boundaries, remove unused access, use short-lived role credentials, and monitor IAM activity through CloudTrail and alerting.

---

### CLOUD-02 — Excessive or public S3 exposure

**Cloud service:** Amazon S3  
**Severity:** High in a real environment; Medium for this controlled exercise  

**Description.** The S3 evidence demonstrates bucket/object enumeration and access to a training object/result. The related FlAWS screenshots demonstrate how storage exposure can disclose information and support further discovery.

**Evidence.** Screenshots 1e–1g show the S3 bucket and object investigation. Screenshot 2a identifies the Pwned Labs S3 activity. Screenshots 2b–2i show the supplementary FlAWS storage-exposure exercise.

**Why is this risky?** Public or overly broad storage access can bypass the intended application access model. The attacker may not need a valid account to retrieve data if the resource is exposed directly.

**Potential impact.** Exposed data may include confidential files, backups, logs, source code, credentials, or internal identifiers. Disclosure can lead to privacy harm, fraud, further compromise, or regulatory consequences.

**Recommendation.** Enable S3 Block Public Access, keep buckets private, use restrictive bucket policies, review object ownership, encrypt data, remove sensitive artifacts, enable access logging, and continuously test the effective public-access state.

---

## 6. Conclusion

The supplied evidence supports a clear cloud-security lesson: access control is a configuration problem as much as it is an identity problem. IAM permissions must be narrow enough to limit the effect of a compromised principal. S3 resources must be private unless public access is explicitly required, reviewed, and monitored.

The exercises improved practical familiarity with AWS IAM and S3 investigation workflows. The next improvement would be to capture a timestamp-visible screenshot for each completed lab and preserve the exact lab completion state alongside the policy or access-control evidence. This would make the evidence package easier for an instructor to verify without relying on inference.

---

## References

[1]: https://app.pwnedlabs.io/labs/intro-to-aws-iam-enumeration "Pwned Labs — Intro to AWS IAM Enumeration"

[2]: https://app.pwnedlabs.io/labs/aws-s3-enumeration-basics "Pwned Labs — AWS S3 Enumeration Basics"

[3]: http://flaws.cloud/ "FlAWS — Amazon Web Services Security Challenge"

[4]: https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html "AWS IAM Best Practices"

[5]: https://docs.aws.amazon.com/AmazonS3/latest/userguide/access-control-block-public-access.html "Amazon S3 Block Public Access"

---

**End of report**
